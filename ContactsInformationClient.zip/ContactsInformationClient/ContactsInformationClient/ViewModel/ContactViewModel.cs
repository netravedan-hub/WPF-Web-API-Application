﻿using ContactsInformationClient.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace ContactsInformationClient.ViewModel
{
    public class ContactViewModel : INotifyPropertyChanged
    {
        public int? _id;

        public int? Id
        {
            get { return _id; }
            set { _id = value; NotifyPropertyChanged("Id"); }
        }

        public string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; NotifyPropertyChanged("FirstName"); }
        }

        public string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; NotifyPropertyChanged("LastName"); }
        }

        public string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; NotifyPropertyChanged("Email"); }
        }

        public string _phoneNumber;

        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { _phoneNumber = value; NotifyPropertyChanged("PhoneNumber"); }
        }

        public string _status;

        public string Status
        {
            get { return _status; }
            set { _status = value; NotifyPropertyChanged("Status"); }
        }



        public List<PersonVO> _persons;

        public List<PersonVO> Persons
        {
            get { return _persons; }
            set { _persons = value; NotifyPropertyChanged("Persons"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }

        }

        public int ListCount { get; set; }
        public ICommand SearchCommand { get; set; }

        public ICommand InsertCommand { get; set; }

        public ICommand DeleteCommand { get; set; }

        public ICommand UpdateCommand { get; set; }

        public ICommand RefreshCommand { get; set; }

        public ContactViewModel()
        {
            SearchCommand = new ContactInfoCommand(SearchContactDetails, canExecuteMethod);
            InsertCommand = new ContactInfoCommand(InsertContactDetails, canExecuteMethod);
            DeleteCommand = new ContactInfoCommand(DeleteContactDetails, canExecuteMethod);
            UpdateCommand = new ContactInfoCommand(UpdateContactDetails, canExecuteMethod);
            RefreshCommand = new ContactInfoCommand(RefreshContactDetails, canExecuteMethod);
        }

        private bool canExecuteMethod(object para)
        {
            return true;
        }
        /// <summary>
        /// Search contact details
        /// </summary>
        /// <param name="para"></param>
        private void SearchContactDetails(object para)
        {
            GetContactDetails();
        }

        /// <summary>
        /// Insert Contact Details
        /// </summary>
        /// <param name="para"></param>
        private void InsertContactDetails(object para)
        {
            AddContactDetails();
        }

        /// <summary>
        /// Delete contact Details
        /// </summary>
        /// <param name="para"></param>
        private void DeleteContactDetails(object para)
        {
            DeleteContactDetails();
        }

        /// <summary>
        /// Update contact details
        /// </summary>
        /// <param name="para"></param>
        private void UpdateContactDetails(object para)
        {
            UpdateContactDetails();
        }
        private void GetContactDetails()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:50713/");
            client.DefaultRequestHeaders.Accept.Add(
                   new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = new HttpResponseMessage();

            if (Id == null)
            {
                response = client.GetAsync("api/Contacts").Result;
            }
            else
            {
                response = client.GetAsync("api/Contacts/" + Id).Result;
            }
            if (response.IsSuccessStatusCode)
            {
                var contacts = response.Content.ReadAsAsync<List<PersonVO>>().Result;
                ListCount = contacts.Count;
                Persons = contacts;
            }
            else
            {
                MessageBox.Show("Error Code" + response.StatusCode + " : Message - " + response.ReasonPhrase);
            }
        }

        private void AddContactDetails()
        {
            GetContactDetails();
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:50713/");
            client.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));
            var personVO = new PersonVO();
            personVO.FirstName = FirstName;
            personVO.LastName = LastName;
            personVO.PhoneNumber = PhoneNumber;
            personVO.Email = Email;
            personVO.Status = Status;
            personVO.Id = Id;
            var response = client.PostAsJsonAsync("api/Contacts", personVO).Result;
            if (response.IsSuccessStatusCode)
            {
                ResetContactDetails();
                MessageBox.Show("Employee Added");

            }
            else
            {

                MessageBox.Show("Error Code" + response.StatusCode + " : Message - " + response.ReasonPhrase);
            }

        }

        private void DeleteContactDetails()
        {
            if (Id == 0)
            {
                MessageBox.Show("Please enter Id to delete");
                return;
            }
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:50713/");
            var id = Id;
            var url = "api/Contacts/" + id;
            HttpResponseMessage response = client.DeleteAsync(url).Result;
            if (response.IsSuccessStatusCode)
            {
                MessageBox.Show("User Deleted");
                ResetContactDetails();

            }
            else
            {
                MessageBox.Show("Error Code" + response.StatusCode + " : Message - " + response.ReasonPhrase);

            }

        }
        private void UpdateContactDetails()
        {
            GetContactDetails();
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:50713/");
            client.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));
            var personVO = new PersonVO();
            personVO.FirstName = FirstName;
            personVO.LastName = LastName;
            personVO.PhoneNumber = PhoneNumber;
            personVO.Email = Email;
            personVO.Status = Status;
            personVO.Id = Id;
            var response = client.PutAsJsonAsync("api/Contacts", personVO).Result;
            if (response.IsSuccessStatusCode)
            {
                ResetContactDetails();
                MessageBox.Show("Employee Updated");

            }
            else
            {

                MessageBox.Show("Error Code" + response.StatusCode + " : Message - " + response.ReasonPhrase);
            }

        }

        private void RefreshContactDetails(object para)
        {
            ResetContactDetails();
        }
        private void ResetContactDetails()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:50713/");
            client.DefaultRequestHeaders.Accept.Add(
                   new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = new HttpResponseMessage();
            response = client.GetAsync("api/Contacts").Result;
            if (response.IsSuccessStatusCode)
            {
                var contacts = response.Content.ReadAsAsync<List<PersonVO>>().Result;
                ListCount = contacts.Count;
                Persons = contacts;
            }
            else
            {
                MessageBox.Show("Error Code" + response.StatusCode + " : Message - " + response.ReasonPhrase);
            }

            FirstName = string.Empty;
            LastName = string.Empty;
            PhoneNumber = string.Empty;
            Email = string.Empty;
            Status = string.Empty;
            Id = (int?)null;
        }

    }
}
