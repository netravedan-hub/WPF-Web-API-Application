﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ContactsInformationClient.Command
{
    public class ContactInfoCommand : ICommand
    {
        Action<object> executeMethod;
        Func<object, bool> canExecute;

        public event EventHandler CanExecuteChanged;

        public ContactInfoCommand(Action<object> excuteMethod, Func<object, bool> canExecute)
        {
            this.executeMethod = excuteMethod;
            this.canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            executeMethod(parameter);
        }
    }
}
