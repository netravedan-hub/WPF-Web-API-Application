﻿using ContactsInformationClient.ViewModel;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Windows;

namespace ContactsInformationClient
{
    /// <summary>
    /// Interaction logic for ContactInformation.xaml
    /// </summary>
    public partial class ContactInformation : Window
    {
        public ContactInformation()
        {
            InitializeComponent();

        }
    }
}
