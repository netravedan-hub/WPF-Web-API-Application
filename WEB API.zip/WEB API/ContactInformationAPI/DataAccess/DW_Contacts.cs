﻿using ContactInformationAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ContactInformationAPI.DataAccess
{
    public class DW_Contacts
    {
        /// <summary>
        /// Get contact details
        /// </summary>
        /// <returns></returns>
        public List<PersonVO> GetContactDetails()
        {
            string connectionString = "";//Enter sql server connection string
            List<PersonVO> personVO = new List<PersonVO>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string selectQuery = "Select * from ContactDetails";
                using (SqlCommand cmd = new SqlCommand(selectQuery))
                {
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            personVO.Add(new PersonVO
                            {
                                Id = Convert.ToInt32(sdr["Id"]),
                                FirstName = sdr["FirstName"].ToString(),
                                LastName = sdr["LastName"].ToString(),
                                PhoneNumber = sdr["PhoneNumber"].ToString(),
                                Email = sdr["Email"].ToString(),
                                Status = sdr["CurrentStatus"].ToString(),

                            });
                        }
                    }
                    con.Close();
                }

            }
            return personVO;
        }


        /// <summary>
        /// Get contact details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public List<PersonVO> GetContactDetailsOnId(int id)
        {
            string connectionString = "";//Enter sql server connection string
            List<PersonVO> personVO = new List<PersonVO>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string selectQuery = "Select * from ContactDetails where Id=@id";
                using (SqlCommand cmd = new SqlCommand(selectQuery))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            personVO.Add(new PersonVO
                            {
                                Id = Convert.ToInt32(sdr["Id"]),
                                FirstName = sdr["FirstName"].ToString(),
                                LastName = sdr["LastName"].ToString(),
                                PhoneNumber = sdr["PhoneNumber"].ToString(),
                                Email = sdr["Email"].ToString(),
                                Status = sdr["CurrentStatus"].ToString(),

                            });
                        }
                        con.Close();
                    }

                }
                return personVO;
            }

        }
        /// <summary>
        /// Insert contact details
        /// </summary>
        /// <param name="personVO"></param>
        public void InsertPersonDetails(PersonVO personVO)
        {
            string connstring = "";//Enter sql server connection string
            string sqlText = "Insert into ContactDetails values(@Id,@FirstName,@LastName,@PhoneNumber,@Email,@CurrentStatus)";
            using (SqlConnection conn = new SqlConnection(connstring))
            {
                SqlCommand sqlCmd = new SqlCommand(sqlText, conn);
                sqlCmd.Parameters.AddWithValue("@Id", personVO.Id);
                sqlCmd.Parameters.AddWithValue("@FirstName", personVO.FirstName);
                sqlCmd.Parameters.AddWithValue("@LastName", personVO.LastName);
                sqlCmd.Parameters.AddWithValue("@PhoneNumber", personVO.PhoneNumber);
                sqlCmd.Parameters.AddWithValue("@Email", personVO.Email);
                sqlCmd.Parameters.AddWithValue("@CurrentStatus", personVO.Status);
                conn.Open();
                int i = sqlCmd.ExecuteNonQuery();
                conn.Close();
            }

        }

        /// <summary>
        /// Update contact details
        /// </summary>
        /// <param name="personVO"></param>
        public void UpdatePersonDetails(PersonVO personVO)
        {
            string connstring = "";//Enter sql server connection string
            string sqlText = "Update ContactDetails set FirstName=@FirstName,LastName=@LastName,PhoneNumber=@PhoneNumber,Email=@Email,CurrentStatus=@CurrentStatus where Id=@Id";
            using (SqlConnection conn = new SqlConnection(connstring))
            {
                SqlCommand sqlCmd = new SqlCommand(sqlText, conn);
                sqlCmd.Parameters.AddWithValue("@Id", personVO.Id);
                sqlCmd.Parameters.AddWithValue("@FirstName", personVO.FirstName);
                sqlCmd.Parameters.AddWithValue("@LastName", personVO.LastName);
                sqlCmd.Parameters.AddWithValue("@PhoneNumber", personVO.PhoneNumber);
                sqlCmd.Parameters.AddWithValue("@Email", personVO.Email);
                sqlCmd.Parameters.AddWithValue("@CurrentStatus", personVO.Status);
                conn.Open();
                int i = sqlCmd.ExecuteNonQuery();
                conn.Close();
            }

        }
        /// <summary>
        /// Delete contact details
        /// </summary>
        /// <param name="id"></param>
        public void DeletePersonDetails(int id)
        {
            string connstring = "";//Enter sql server connection string
            string sqlText = "Delete from ContactDetails where Id=@id";
            using (SqlConnection conn = new SqlConnection(connstring))
            {
                SqlCommand sqlCmd = new SqlCommand(sqlText, conn);
                sqlCmd.Parameters.AddWithValue("@Id", id);
                conn.Open();
                int i = sqlCmd.ExecuteNonQuery();
                conn.Close();
            }

        }
    }
}