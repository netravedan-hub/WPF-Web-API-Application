﻿using ContactInformationAPI.DataAccess;
using ContactInformationAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ContactInformationAPI.Controllers
{
    public class ContactsController : ApiController
    {
        // GET api/<controller>
        [HttpGet]
        public List<PersonVO> GetContactDetails()
        {
            DW_Contacts dW_Contacts = new DW_Contacts();
            List<PersonVO> personVOList = new List<PersonVO>();
            personVOList = dW_Contacts.GetContactDetails();
            return personVOList;
        }

        // GET api/<controller>/5
        [HttpGet]
        public List<PersonVO> GetContactDetailsBasedOnId(int id)
        {
            DW_Contacts dW_Contacts = new DW_Contacts();
            List<PersonVO> personVOList = new List<PersonVO>();
            personVOList = dW_Contacts.GetContactDetailsOnId(id);
            return personVOList;

        }

        // POST api/<controller>
        public void Post(PersonVO personVO)
        {

            DW_Contacts dW_Contacts = new DW_Contacts();
            dW_Contacts.InsertPersonDetails(personVO);
        }
       
        // PUT api/<controller>
        public void PUT(PersonVO personVO)
        {

            DW_Contacts dW_Contacts = new DW_Contacts();
            dW_Contacts.UpdatePersonDetails(personVO);
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
            DW_Contacts dW_Contacts = new DW_Contacts();
            dW_Contacts.DeletePersonDetails(id);
        }
    }
}
